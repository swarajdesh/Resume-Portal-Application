package com.swarajdeshmukh.resumeportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumePortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
